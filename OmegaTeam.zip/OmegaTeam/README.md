## OmegaTeam

Simple LineFollower for RoboCup Rescue<br/>
WIP...<br/>
